const XMLHttpRequest=require('xmlhttprequest').XMLHttpRequest

    //Funcion para la solicitud de la PokeApi mediante un programa
    function getPokemon(pokemonName,callback){

        //Url de la PokeApi
        const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

        //Crear la instancia
        const xhr=new XMLHttpRequest()

        //configurar la solicitud
        xhr.open("GET", apiUrl,true)

        //Carga exitosa
        xhr.onload = function(){
            if(xhr.status===200){

                //Pasear JSON
                const data = JSON.parse(xhr.responseText)
                const name=data.name
                callback(null,name)
            }else{
                const error = new Error(`Error: ${xhr.status}`) 
                callback(error,null)  
            }
        }
        //Manejo de errores de red
        xhr.onerror = function(){
            const error = new Error(`Error: ${xhr.status}`) 
            callback(error,null)      
        }
        //Enviar solicitud 
        xhr.send()
    } 
    function getPokemonweight(pokemonName,callback){
        //Url de la PokeApi
        const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

        //Crear la instancia
        const xhr=new XMLHttpRequest()

        //configurar la solicitud
        xhr.open("GET", apiUrl,true)

        //Carga exitosa
        xhr.onload = function(){
            if(xhr.status===200){

                //Pasear JSON
                const data = JSON.parse(xhr.responseText)
                const weight=data.weight
                callback(null,weight)
            }else{
                const error = new Error(`Error: ${xhr.status}`) 
                callback(error,null)  
            }
        }
        //Manejo de errores de red
        xhr.onerror = function(){
            const error = new Error(`Error: ${xhr.status}`) 
            callback(error,null)      
        }
        //Enviar solicitud 
        xhr.send()
    }
    function getPokemonAbilities(pokemonName,callback){
        //Url de la PokeApi
        const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

        //Crear la instancia
        const xhr=new XMLHttpRequest()

        //configurar la solicitud
        xhr.open("GET", apiUrl,true)

        //Carga exitosa
        xhr.onload = function(){
            if(xhr.status===200){

                //Pasear JSON
                const data = JSON.parse(xhr.responseText)
                const abilities=data.abilities.map((pokemonsito)=>pokemonsito.ability.name)
                callback(null,abilities)
            }else{
                const error = new Error(`Error: ${xhr.status}`) 
                callback(error,null)  
            }
        }
        //Manejo de errores de red
        xhr.onerror = function(){
            const error = new Error(`Error: ${xhr.status}`) 
            callback(error,null)      
        }
        //Enviar solicitud 
        xhr.send()
    }


        // Mostrar el Nombre
        getPokemon("pikachu",(error,name)=>{
            if(error){
                console.error(`Error: ${error.message}`)
            }else{
                console.log("Nombre",name)
            }
        })
        
        //Mostrar el Peso
        getPokemonweight("pikachu",(error,weight)=>{
            if(error){
                console.error(`Error${error.message}`)
            }else{
                console.log("Peso",weight)
            }
        })

        //Mostrar poder de Habilidad        
        getPokemonAbilities("pikachu",(error,abilities)=>{
            if(error){
                console.error(`Error${error.message}`)
            }else{
                console.log("habilidad",abilities)                
            }
        })
            
    