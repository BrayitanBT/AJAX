const axios=require('axios')
const pokemonName='pikachu'
const ApiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`
axios(`${ApiUrl}`)
.then(response=>{
    return axios.get(`${ApiUrl}`)
    .then((response)=>{
        return response.data
    })
})
.then(response=>{
    console.log(`Nombre: ${response.name}`)
    console.log(`Peso: ${response.weight}`)
    console.log(`habilidades: ${response.abilities.map((abi)=>abi.ability.name)}`)
    console.log(response.species.url)
    
})
.catch(err=>{
    console.error(err)
})
