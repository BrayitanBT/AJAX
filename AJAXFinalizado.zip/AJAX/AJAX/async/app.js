const axios=require('axios')
const pokemonName = 'Charmander'
const ApiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

const pokeData= async()=>{
    try{
        const response = await axios.get(`${ApiUrl}`)

        console.log(`Nombre: ${response.data.name}`)
        console.log(`Peso: ${response.data.weight}`)
        console.log(`Habilidades: ${response.data.abilities.map((abi)=>abi.ability.name)}`)
        const ApiUrl2 = response.data.species.url
        const response2 = await axios.get(`${ApiUrl2}`)
        
        const ApiUrl3 = response2.data.evolution_chain.url
        const response3 = await axios.get(`${ApiUrl3}`)
        console.log(response3.data.chain.evolves_to[0].species.name)

    }
    catch(error){
        console.log(error)
    }
}
pokeData()